
@extends('layouts.app')

@section('content')
<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Loan Details - #{{ $loan->id }}</h3>
        <a href="{{ route('admin.loan.approvals') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>
    </div>

    <div class="row">
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5>Loan Information</h5>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <tr>
                            <th>Ref No</th>
                            <td>{{ $loan->ref_no }}</td>
                        </tr>
                        <tr>
                            <th>Bank Name</th>
                            <td>{{ $loan->bank_name }}</td>
                        </tr>
                        <tr>
                            <th>Staff Name</th>
                            <td>{{ $loan->staff_name }}</td>
                        </tr>
                        <tr>
                            <th>Customer Name</th>
                            <td>{{ $loan->customer_name }}</td>
                        </tr>
                        <tr>
                            <th>Percentage</th>
                            <td>
                                @if($loan->old_percentage)
                                    <del class="text-muted">{{ $loan->old_percentage }}%</del>
                                    → <strong class="text-success">{{ $loan->percentage }}%</strong>
                                @else
                                    {{ $loan->percentage }}%
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Interest Amount</th>
                            <td>
                                @if($loan->old_interest_amount)
                                    <del class="text-muted">₹{{ number_format((float)$loan->old_interest_amount, 2) }}</del>
                                    → <strong class="text-success">₹{{ number_format((float)$loan->interest_amount, 2) }}</strong>
                                @else
                                    ₹{{ number_format((float)$loan->interest_amount, 2) }}
                                @endif
                            </td>
                        </tr>
                        <tr>
                            <th>Period</th>
                            <td>{{ $loan->period_count }} {{ $loan->interest_period }}</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <h5>Bank Statement Details</h5>
                </div>
                <div class="card-body">
                    @if($loan->statement)
                    <table class="table table-bordered">
                        <tr>
                            <th>Date</th>
                            <td>{{ $loan->statement->date ? \Carbon\Carbon::parse($loan->statement->date)->format('d-m-Y') : '-' }}</td>
                        </tr>
                        <tr>
                            <th>UTR No</th>
                            <td>{{ $loan->statement->utrno }}</td>
                        </tr>
                        <tr>
                            <th>Amount</th>
                            <td class="text-end">₹{{ number_format((float)$loan->statement->amount, 2) }}</td>
                        </tr>
                        <tr>
                            <th>Name</th>
                            <td>{{ $loan->statement->name }}</td>
                        </tr>
                        <tr>
                            <th>Remarks</th>
                            <td>{{ $loan->statement->remarks }}</td>
                        </tr>
                    </table>
                    @endif
                </div>
            </div>
        </div>
    </div>

    {{-- KYC Documents --}}
    @if($loan->files->count() > 0)
    <div class="card mb-4">
        <div class="card-header bg-secondary text-white">
            <h5>KYC Documents</h5>
        </div>
        <div class="card-body">
            <div class="row">
                @foreach($loan->files as $file)
                <div class="col-md-3 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-file-pdf fa-3x text-danger mb-2"></i>
                            <p class="mb-1"><small>{{ $file->filename }}</small></p>
                            <a href="{{ asset('storage/' . $file->filepath) }}" target="_blank" class="btn btn-sm btn-primary">
                                <i class="fas fa-eye"></i> View
                            </a>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
    @endif

    {{-- Approval Actions --}}
    @if($loan->approval_status === 'pending')
    <div class="card border-warning">
        <div class="card-header bg-warning">
            <h5>⏳ Pending Approval Actions</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.loan.approve', $loan->id) }}" method="POST" class="d-inline">
                @csrf
                <button type="submit" class="btn btn-success btn-lg" onclick="return confirm('Are you sure you want to approve this loan?')">
                    <i class="fas fa-check-circle"></i> Approve Loan
                </button>
            </form>

            <button type="button" class="btn btn-danger btn-lg" data-bs-toggle="modal" data-bs-target="#rejectModal">
                <i class="fas fa-times-circle"></i> Reject Loan
            </button>
        </div>
    </div>
    @endif

    @if($loan->approval_status === 'approved')
    <div class="alert alert-success">
        <h5>✓ Approved</h5>
        <p>Approved by: {{ $loan->approver->name ?? 'Admin' }}</p>
        <p>Approved at: {{ $loan->approved_at->format('d-m-Y h:i A') }}</p>
    </div>
    @endif

    @if($loan->approval_status === 'rejected')
    <div class="alert alert-danger">
        <h5>✗ Rejected</h5>
        <p><strong>Reason:</strong> {{ $loan->rejection_reason }}</p>
    </div>
    @endif
</div>

{{-- Reject Modal --}}
<div class="modal fade" id="rejectModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.loan.reject', $loan->id) }}" method="POST">
                @csrf
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title">Reject Loan #{{ $loan->id }}</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Rejection Reason <span class="text-danger">*</span></label>
                        <textarea name="rejection_reason" class="form-control" rows="4" required 
                                  placeholder="Provide detailed reason for rejection..."></textarea>
                    </div>
                    <div class="alert alert-warning">
                        <strong>Warning:</strong> Rejecting will:
                        <ul>
                            <li>Restore old percentage and interest values</li>
                            <li>Unhide all related bank statements</li>
                            <li>Mark loan as rejected</li>
                        </ul>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-times"></i> Confirm Rejection
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection